import { Text } from 'react-native';

const PostScreen = () => {
  return <Text>PostScreen</Text>;
};

export default PostScreen;
