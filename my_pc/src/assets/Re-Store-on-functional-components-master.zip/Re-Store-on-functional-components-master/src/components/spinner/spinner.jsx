import React from "react"
import "./spinner.css"

const Spinner = () => {
	return <div className="loader">loading...</div>
}

export default Spinner
