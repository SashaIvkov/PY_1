import React from "react"

const CardPage = () => {
	return <div>Card Page</div>
}

export default CardPage
